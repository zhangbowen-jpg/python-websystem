from django.apps import AppConfig


class EchartConfig(AppConfig):
    name = 'echart'
