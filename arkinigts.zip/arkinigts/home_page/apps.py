from django.apps import AppConfig


class HomePageConfig(AppConfig):
    name = 'home_page'
