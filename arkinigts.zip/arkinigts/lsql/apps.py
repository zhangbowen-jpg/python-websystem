from django.apps import AppConfig


class LsqlConfig(AppConfig):
    name = 'lsql'
